All code is provided within Jupyter notebooks [in this directory](https://github.com/jonkrohn/DLTFpT/blob/master/notebooks/). These notebooks are intended for use within the (free) [Colab cloud environment](https://colab.research.google.com), which requires no installation.

Nothing else in this directory matters at this time. Feel free to ignore.

Step 9: `sudo docker run -v $(pwd):/home/jovyan/work -it --rm -p 8896:8888 mlf-stack`
